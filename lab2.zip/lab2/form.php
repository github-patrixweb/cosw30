<!doctype html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<title>Form Feedback</title>
</head>
<body>
<?php 
/* Patrixweb
display name

/*
echo "<h1>" . $_Post['first_name'] . "</h1>"
?>
</body>
</html>